﻿var db = openDatabase('monkerDB', '1.0', 'Test DB', 2 * 1024 * 1024);


db.transaction(function (tx) {
    tx.executeSql('SELECT * FROM weights', [], function (tx, results) {
        var len = results.rows.length, i;
        
        for (i = 0; i < len; i++) {
            msg = "<p><b>" + results.rows.item(i).log + "</b></p>";

            var documentIDus= '#us' + results.rows.item(i).weightClass;
            var documentIDthem = '#them' + results.rows.item(i).weightClass;

            //$(documentID).select(results.rows.item(i).them);
            $(documentIDus).val(results.rows.item(i).us);
            $(documentIDthem).val(results.rows.item(i).them);

            if (results.rows.item(i).them > 0)
                $(documentIDthem).addClass('highlight');
            else if (results.rows.item(i).us > 0)
                $(documentIDus).addClass('highlight');
        }
        getFinalScore();
    }, null);

   
});

function clearCache() {
    db.transaction(function (tx) {
        tx.executeSql('DROP TABLE weights');
    });

    window.location.reload(true);
    getFinalScore();
};

function CalcScore(event) {


    validateBox(event.id);
    addHighlight(event);


    var first = event.id.substr(0, 2);
    var weight = event.id.substr(event.id.length - 3);
    var usThem;
    if (first === 'us')
        usThem = 'us';
    else
        usThem = 'them';


   
  
    if (usThem == 'us') {
        db.transaction(function (tx) {
            tx.executeSql('update weights set us =?, them = 0 where weightClass=?', [parseInt(event.value), weight], function (transaction, result) {
            }, function (transaction, error) {
                console.log(error);
            });
        }, transError, transSuccess);
    }
    else {
        db.transaction(function (tx) {
            tx.executeSql('update weights set them =?, us = 0 where weightClass=?', [parseInt(event.value), weight], function (transaction, result) {
            }, function (transaction, error) {
                console.log(error);
            });
        }, transError, transSuccess);
    }

    function transError(t, e) {
        console.log(t);
        console.log(e);
        console.error("Error occured ! Code:" + e.code + " Message : " + e.message);
    }

    function transSuccess(t, r) {
        console.info("Transaction completed Successfully!");
        console.log(t);
        console.log(r);
    }

    
    getFinalScore();

};



function getFinalScore() {
    var scoreUs = 0;
    $('.weightSelectUs  option:selected').each(function () {
        scoreUs += parseInt($(this).text());
    });



    var scoreThem = 0;
    $('.weightSelectThem  option:selected').each(function () {
        scoreThem += parseInt($(this).text());
    });

    $('#us').html(scoreUs);
    $('#them').html(scoreThem);


    if (scoreUs > scoreThem) {
        $('#finalUs').addClass('highlight');
        $('#finalThem').removeClass('highlight');
    }
    else if (scoreUs < scoreThem) {
        $('#finalUs').removeClass('highlight');
        $('#finalThem').addClass('highlight');
    }
    else if (scoreUs === 0 && scoreThem === 0) {
        $('#finalUs').removeClass('highlight');
        $('#finalThem').removeClass('highlight');
    }
    else {
        $('#finalUs').addClass('highlight');
        $('#finalThem').addClass('highlight');
    }


};

function addHighlight(elemName) {
    $(elemName).addClass('highlight');

    var first = elemName.id.substr(0, 2);
    var weight = elemName.id.substr(elemName.id.length - 3);
    if (first === 'us') {
        //check them to see if there is a value, if there is, 0 it out
        var themElem = '#them' + weight;
        $(themElem).removeClass('highlight');
    }
    else {
        var usElem = '#us' + weight;
        $(usElem).removeClass('highlight');
    }


};

function validateBox(eleName) {

    var first = eleName.substr(0, 2);
    var weight = eleName.substr(eleName.length - 3);
    if (first === 'us'){
        //check them to see if there is a value, if there is, 0 it out
        var themElem = '#them' + weight;
        $(themElem).val('0');
    }
    else {
        var usElem = '#us' + weight;
        $(usElem).val('0');
    }
    

};